/**
* Interface PuedeVolar.
@author Javi Sirvent
*/
public interface PuedeVolar{
	/**
	* Método abstracto.
	*/
	public abstract String volar();
}