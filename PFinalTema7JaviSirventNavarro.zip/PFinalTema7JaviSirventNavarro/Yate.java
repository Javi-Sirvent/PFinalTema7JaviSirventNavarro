/**
* Clase Yate.
* tieneCocina El valor de la cocina del Yate.
* numMotores El valor del númeor de motores del Yate.
* metrosEslora El valor de los metros de eslora del Yate.
@author Javi Sirvent
*/
public class Yate extends Vehiculo implements PuedeNavegar{
	
	private boolean tieneCocina;
	private int numMotores;
	private double metrosEslora;
	
	/**
	* Crea un Yate nuevo llamando al constructor de la clase Vehiculo.
	*/
	public Yate(){
		super();
		setTieneCocina(false);
		setNumMotores(2);
		setMetrosEslora(50);
	}
	
	/**
	* Crea un Yate nuevo con los párametros recibidos llamando al constructor de la clase Vehiculo.
	*/
	public Yate(String marca, String modelo, String color, double kilometros, int numPuertas, int numPlazas, boolean tieneCocina, int numMotores, double metrosEslora){
		super(marca, modelo, color, kilometros, numPuertas, numPlazas);
		setTieneCocina(tieneCocina);
		setNumMotores(numMotores);
		setMetrosEslora(metrosEslora);
	}
	
	/**
	* Devuelve una cadena de texto con las caracteristicas del Yate recibido por parámetro.
	* @param y Yate recibido por parámetro
	* @return La cadena de texto creada.
	*/
	public String toString(Yate y){
		String cocina;
		if(y.tieneCocina){
			cocina = " y tiene cocina. \n";
		}
		else{
			cocina = " y no tiene cocina. \n";
		}
		String s = "El yate tiene " + y.metrosEslora + "m de eslora, " + y.numMotores + " motores" + cocina + super.toString(y);
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza el Yate.
	* @return s La acción que realiza el Yate.
	*/
	public String navegar(){
		String s = "Este vehiculo es un yate. Puede navegar por el mar y el oceano.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza el Yate.
	* @return s La acción que realiza el Yate.
	*/
	public String zarpar(){
		String s = "El yate esta zarpando.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza el Yate.
	* @return s La acción que realiza el Yate.
	*/
	public String atracar(){
		String s = "El yate esta atracando.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza el Yate.
	* @return s La acción que realiza el Yate.
	*/
	public String arrancar(){
		String s = "El yate esta arrancando.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza el Yate.
	* @return s La acción que realiza el Yate.
	*/
	public String acelerar(){
		String s = "El yate esta acelerando.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza el Yate.
	* @return s La acción que realiza el Yate.
	*/
	public String frenar(){
		String s = "El yate esta frenando.\n";
		return s;
	}
	
	/**
	* Asigna el valor de la cocina del Yate.
	* @param t El valor de la variable tieneCocina.
	*/
	public void setTieneCocina(boolean t){
		tieneCocina = t;
	}
	
	/**
	* Devuelve el valor de la variable tieneCocina
	* @return El valor de la variable tieneCocina
	*/
	public boolean getTieneCocina(){
		return tieneCocina;
	}
	
	/**
	* Asigna el valor del número de motores del Yate.
	* @param n El valor de la variable numMotores.
	*/
	public void setNumMotores(int n){
		numMotores = n;
	}
	
	/**
	* Devuelve el valor de la variable numMotores
	* @return El valor de la variable numMotores
	*/
	public int getNumMotores(){
		return numMotores;
	}
	
	/**
	* Asigna el valor de los metros de eslora del Yate.
	* @param m El valor de la variable metrosEslora.
	*/
	public void setMetrosEslora(double m){
		metrosEslora = m;
	}
	
	/**
	* Devuelve el valor de la variable metrosEslora
	* @return El valor de la variable metrosEslora
	*/
	public double getMetrosEslora(){
		return metrosEslora;
	}
}