/**
* Interface PuedeCircular.
@author Javi Sirvent
*/
public interface PuedeCircular{
	/**
	* Método abstracto.
	*/
	public abstract String circular();
}