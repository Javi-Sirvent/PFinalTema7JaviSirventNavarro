/**
* Clase Vehiculo.
* MAX_VEHICULOS El número máximo de vehiculos que se pueden crear.
* vehiculosCount El contador de vehiculos creados.
* matricula El valor de la matrícula del vehiculo.
* marca El valor de la marca del vehiculo.
* modelo El valor del modelo del vehiculo.
* color El valor del color del vehiculo.
* kilometros El valor de los kilometros del vehiculo.
* numPuertas El valor del número de puertas del vehiculo.
* numPlazas El valor del número de plazas del vehiculo.
@author Javi Sirvent
*/

public abstract class Vehiculo{
	
	public static final int MAX_VEHICULOS = 5;
	public static int vehiculosCount = 0;
	
	protected String matricula;
	protected String marca;
	protected String modelo;
	protected String color = "blanco";
	protected double kilometros = 0;
	protected int numPuertas;
	protected int numPlazas;
	
	/**
	* Método abstracto.
	*/
	public abstract String arrancar();
	
	/**
	* Método abstracto.
	*/
	public abstract String acelerar();
	
	/**
	* Método abstracto.
	*/
	public abstract String frenar();
	
	/**
	* Crea un nuevo Vehiculo si el contador es menor que el máximo permitido.
	*/
	public Vehiculo(){
		if(vehiculosCount < MAX_VEHICULOS){
			setMatricula(generaMatricula());
			setMarca("Generico");
			setModelo("Generico");
			setColor("blanco");
			setKilometros(0);
			setNumPuertas(0);
			setNumPlazas(0);
			vehiculosCount++;
		}
	}
	
	/**
	* Crea un nuevo Vehiculo con los parámetros recibidos si el contador es menor que el máximo permitido.
	*/
	public Vehiculo(String marca, String modelo, String color, double kilometros, int numPuertas, int numPlazas){
		if(vehiculosCount < MAX_VEHICULOS){
			setMatricula(generaMatricula());
			setMarca(marca);
			setModelo(modelo);
			setColor(color);
			setKilometros(kilometros);
			setNumPuertas(numPuertas);
			setNumPlazas(numPlazas);
			vehiculosCount++;
		}
	}
	
	/**
	* Devuelve una cadena de texto con las caracteristicas del vehiculo recibido por parámetro.
	* @param v Vehiculo recibido por parámetro
	* @return La cadena de texto creada.
	*/
	public String toString(Vehiculo v){
		String s = "La matricula es " + v.matricula + ", es de la marca " + v.marca + " y el modelo " + v.modelo + ". \n" + "Es de color " + v.color + ", tiene " + v.kilometros + "km, " + v.numPlazas + " plazas y " + v.numPuertas + " puertas. \n";
		return s;
	}
	
	/**
	* Devuelve una matrícula aleatoria. 
	* @return El valor de la matricula creada.
	*/
	public String generaMatricula(){
		String mat = Integer.toString((int) (Math.random() * 100000));
		return mat;
	}
	
	/**
	* Asigna la matrícula al vehiculo.
	* @param m El valor de la variable matricula.
	*/
	public void setMatricula(String m){
		matricula = m;
	}
	
	/**
	*Devuelve el valor de la variable matricula
	*@return El valor de la variable matricula
	*/
	public String getMatricula(){
		return matricula;
	}
	
	/**
	* Asigna la marca al vehiculo.
	* @param m El valor de la variable marca.
	*/
	public void setMarca(String m){
		marca = m;
	}
	
	/**
	*Devuelve el valor de la variable marca
	*@return El valor de la variable marca
	*/
	public String getMarca(){
		return marca;
	}
	
	/**
	* Asigna el modelo al vehiculo.
	* @param m El valor de la variable modelo.
	*/
	public void setModelo(String m){
		modelo = m;
	}
	
	/**
	*Devuelve el valor de la variable modelo
	*@return El valor de la variable modelo
	*/
	public String getModelo(){
		return modelo;
	}
	
	/**
	* Asigna el color al vehiculo.
	* @param c El valor de la variable color.
	*/
	public void setColor(String c){
		color = c;
	}
	
	/**
	*Devuelve el valor de la variable color
	*@return El valor de la variable color
	*/
	public String getColor(){
		return color;
	}
	
	/**
	* Asigna los kilometros al vehiculo.
	* @param km El valor de la variable kilometros.
	*/
	public void setKilometros(double km){
		kilometros = km;
	}
	
	/**
	*Devuelve el valor de la variable kilometros
	*@return El valor de la variable kilometros
	*/
	public double getKilometros(){
		return kilometros;
	}
	
	/**
	* Asigna el número de puertas al vehiculo.
	* @param n El valor de la variable numPuertas.
	*/
	public void setNumPuertas(int n){
		numPuertas = n;
	}
	
	/**
	*Devuelve el valor de la variable numPuertas
	*@return El valor de la variable numPuertas
	*/
	public int getNumPuertas(){
		return numPuertas;
	}
	
	/**
	* Asigna el número de plazas al vehiculo.
	* @param n El valor de la variable numPlazas.
	*/
	public void setNumPlazas(int n){
		numPlazas = n;
	}
	
	/**
	*Devuelve el valor de la variable numPlazas
	*@return El valor de la variable numPlazas
	*/
	public int getNumPlazas(){
		return numPlazas;
	}
}