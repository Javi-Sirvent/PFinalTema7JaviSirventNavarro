/**
* Clase Autobus.
* tipoRecorrido El valor del tipo de recorrido del Autobus.
* esEscolar El valor de tipo de autobus del Autobus.
@author Javi Sirvent
*/
public class Autobus extends Vehiculo implements PuedeCircular{
	
	private String tipoRecorrido;
	private boolean esEscolar;
	
	/**
	* Crea un Autobus nuevo llamando al constructor de la clase Vehiculo.
	*/
	public Autobus(){
		super();
		setTipoRecorrido("Habitual");
		setEsEscolar(false);
	}
	
	/**
	* Crea un Autobus nuevo con los párametros recibidos llamando al constructor de la clase Vehiculo.
	*/
	public Autobus(String marca, String modelo, String color, double kilometros, int numPuertas, int numPlazas, String tipoRecorrido, boolean esEscolar){
		super(marca, modelo, color, kilometros, numPuertas, numPlazas);
		setTipoRecorrido(tipoRecorrido);
		setEsEscolar(esEscolar);
	}
	
	/**
	* Devuelve una cadena de texto con las caracteristicas del Autobus recibido por parámetro.
	* @param a Autobus recibido por parámetro
	* @return La cadena de texto creada.
	*/
	public String toString(Autobus a){
		String escolar;
		if(a.esEscolar){
			escolar = " y es escolar. \n";
		}
		else{
			escolar = " y no es escolar. \n";
		}
		String s = "El autobus tiene un recorrido " + a.tipoRecorrido + escolar + super.toString(a);
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza el Autobus.
	* @return s La acción que realiza el Autobus.
	*/
	public String circular(){
		String s = "Este vehiculo es un autobus. Puede circular por la carretera.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza el Autobus.
	* @return s La acción que realiza el Autobus.
	*/
	public String aparcar(){
		String s = "El autobus esta aparcando.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza el Autobus.
	* @return s La acción que realiza el Autobus.
	*/
	public String abrirPuertas(){
		String s = "El autobus esta abriendo las puertas.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza el Autobus.
	* @return s La acción que realiza el Autobus.
	*/
	public String arrancar(){
		String s = "El autobus esta arrancando.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza el Autobus.
	* @return s La acción que realiza el Autobus.
	*/
	public String acelerar(){
		String s = "El autobus esta acelerando.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza el Autobus.
	* @return s La acción que realiza el Autobus.
	*/
	public String frenar(){
		String s = "El autobus esta frenando.\n";
		return s;
	}
	
	/**
	* Asigna el tipo de recorrido al Autobus.
	* @param t El valor de la variable tipoRecorrido.
	*/
	public void setTipoRecorrido(String t){
		tipoRecorrido = t;
	}
	
	/**
	* Devuelve el valor de la variable tipoRecorrido
	* @return El valor de la variable tipoRecorrido
	*/
	public String getTipoRecorrido(){
		return tipoRecorrido;
	}
	
	/**
	* Asigna el tipo de autobus al Autobus.
	* @param e El valor de la variable esEscolar.
	*/
	public void setEsEscolar(boolean e){
		esEscolar = e;
	}
	
	/**
	* Devuelve el valor de la variable tipoRecorrido
	* @return El valor de la variable tipoRecorrido
	*/
	public boolean getEsEscolar(){
		return esEscolar;
	}
}