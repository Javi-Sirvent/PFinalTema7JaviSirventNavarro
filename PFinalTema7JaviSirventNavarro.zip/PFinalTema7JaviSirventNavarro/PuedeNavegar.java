/**
* Interface PuedeNavegar.
@author Javi Sirvent
*/
public interface PuedeNavegar{
	/**
	* Método abstracto.
	*/
	public abstract String navegar();
}