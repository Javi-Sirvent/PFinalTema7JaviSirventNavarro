/**
* Clase Avioneta.
* aeropuerto El valor del aeropuerto de la Avioneta.
* maxKg El valor del peso máximo de la Avioneta.
@author Javi Sirvent
*/
public class Avioneta extends Vehiculo implements PuedeVolar{
	
	private String aeropuerto;
	private double maxKg;
	
	/**
	* Crea una Avioneta nueva llamando al constructor de la clase Vehiculo.
	*/
	public Avioneta(){
		super();
		setAeropuerto("Barajas");
		setMaxKg(1000);
	}
	
	/**
	* Crea una Avioneta nueva con los párametros recibidos llamando al constructor de la clase Vehiculo.
	*/
	public Avioneta(String marca, String modelo, String color, double kilometros, int numPuertas, int numPlazas, String aeropuerto, double maxKg){
		super(marca, modelo, color, kilometros, numPuertas, numPlazas);
		setAeropuerto(aeropuerto);
		setMaxKg(maxKg);
	}
	
	/**
	* Devuelve una cadena de texto con las caracteristicas de la Avioneta recibida por parámetro.
	* @param a Avioneta recibida por parámetro
	* @return La cadena de texto creada.
	*/
	public String toString(Avioneta a){
		String s = "La avioneta soporta un maximo de " + a.maxKg + "kg y esta en el aeropuerto de " + a.aeropuerto + ". \n" + super.toString(a);
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza la Avioneta.
	* @return s La acción que realiza la Avioneta.
	*/
	public String volar(){
		String s = "Este vehiculo es una avioneta. Puede volar por el cielo.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza la Avioneta.
	* @return s La acción que realiza la Avioneta.
	*/
	public String despegar(){
		String s = "La avioneta esta despegando.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza la Avioneta.
	* @return s La acción que realiza la Avioneta.
	*/
	public String aterrizar(){
		String s = "La avioneta esta aterrizando.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza la Avioneta.
	* @return s La acción que realiza la Avioneta.
	*/
	public String arrancar(){
		String s = "La avioneta esta arrancando.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza la Avioneta.
	* @return s La acción que realiza la Avioneta.
	*/
	public String acelerar(){
		String s = "La avioneta esta acelerando.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza la Avioneta.
	* @return s La acción que realiza la Avioneta.
	*/
	public String frenar(){
		String s = "La avioneta esta frenando.\n";
		return s;
	}
	
	/**
	* Asigna el valor del aeropuerto de la Avioneta.
	* @param a El valor de la variable aeropuerto.
	*/
	public void setAeropuerto(String a){
		aeropuerto = a;
	}
	
	/**
	* Devuelve el valor de la variable aeropuerto
	* @return El valor de la variable aeropuerto
	*/
	public String getAeropuerto(){
		return aeropuerto;
	}
	
	/**
	* Asigna el valor del peso máximo de la Avioneta.
	* @param m El valor de la variable Avioneta.
	*/
	public void setMaxKg(double m){
		maxKg = m;
	}
	
	/**
	* Devuelve el valor de la variable maxKg
	* @return El valor de la variable maxKg
	*/
	public double getMaxKg(){
		return maxKg;
	}
}