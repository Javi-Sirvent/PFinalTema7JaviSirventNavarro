import java.util.*;
import javax.swing.JOptionPane;
/**
* Clase Parque.
* Permite crear y modificar objetos de la clase Coche, Autobus, Motocicleta, Avioneta y Yate.
* @author Javi Sirvent.
*/
public class Parque{
	
	/**
	* Método principal.
	* @param args.
	*/
	public static void main(String[] args){
		
		ArrayList<Vehiculo> parque = new ArrayList<Vehiculo>();
		
		int op = 0;
		String mensaje = "No puedes crear mas vehiculos porque ya has alcanzado el maximo disponible en el almacen.";
		String mensaje2 = "No existe ningun vehiculo con esa matricula.";
		
		do{
		
			try { String opcion = JOptionPane.showInputDialog(null, "Fabrica de Coches de Javi Sirvent Navarro. Selecciona una de las siguientes opciones: \n" 
			+ "1.Fabricar coche (por defecto)\n" + "2.Fabricar autobus (por defecto)\n" + "3.Fabricar motocicleta (por defecto)\n" 
			+ "4.Fabricar avioneta (por defecto)\n" + "5.Fabricar yate (por defecto)\n" + "6.Fabricar coche (con caracteristicas)\n" 
			+ "7.Fabricar autobus (con caracteristicas)\n" + "8.Fabricar motocicleta (con caracteristicas)\n" + "9.Fabricar avioneta (con caracteristicas)\n" 
			+ "10.Fabricar yate (con caracteristicas)\n" + "11.Mostrar las caracteristicas de los vehiculos creados\n" + 
			"12.Mostrar las caracteristicas de los vehiculos (por su matricula)\n" + "13.Salir de la aplicacion.\n");
				op = Integer.parseInt(opcion);
				switch (op){
					case 1:	if(Vehiculo.vehiculosCount == Vehiculo.MAX_VEHICULOS){
								JOptionPane.showMessageDialog(null, mensaje);
								}
							else{
								Coche c = new Coche();
								parque.add(c);
								JOptionPane.showMessageDialog(null, c.toString(c));
							}
							break;
					case 2:	if(Vehiculo.vehiculosCount == Vehiculo.MAX_VEHICULOS){
								JOptionPane.showMessageDialog(null, mensaje);
								}
							else{
								Autobus a = new Autobus();
								parque.add(a);
								JOptionPane.showMessageDialog(null, a.toString(a));
							}
							break;
					case 3:	if(Vehiculo.vehiculosCount == Vehiculo.MAX_VEHICULOS){
								JOptionPane.showMessageDialog(null, mensaje);
								}
							else{
								Motocicleta m = new Motocicleta();
								parque.add(m);
								JOptionPane.showMessageDialog(null, m.toString(m));
							}
							break;
					case 4:	if(Vehiculo.vehiculosCount == Vehiculo.MAX_VEHICULOS){
								JOptionPane.showMessageDialog(null, mensaje);
								}
							else{
								Avioneta av = new Avioneta();
								parque.add(av);
								JOptionPane.showMessageDialog(null, av.toString(av));
							}
							break;
					case 5:	if(Vehiculo.vehiculosCount == Vehiculo.MAX_VEHICULOS){
								JOptionPane.showMessageDialog(null, mensaje);
								}
							else{
								Yate y = new Yate();
								parque.add(y);
								JOptionPane.showMessageDialog(null, y.toString(y));
							}
							break;
					case 6:	if(Vehiculo.vehiculosCount == Vehiculo.MAX_VEHICULOS){
								JOptionPane.showMessageDialog(null, mensaje);
								}
							else{
								String marca = JOptionPane.showInputDialog("Introduce la marca: ");
								String modelo = JOptionPane.showInputDialog("Introduce la modelo: ");
								String color = JOptionPane.showInputDialog("Introduce el color: ");
								String km = JOptionPane.showInputDialog("Introduce los km: ");
								String puer = JOptionPane.showInputDialog("Introduce el numero de puertas: ");
								String plaz = JOptionPane.showInputDialog("Introduce el numero de plazas: ");
								String airbags = JOptionPane.showInputDialog("Introduce el numero de airbags: ");
								String solar = JOptionPane.showInputDialog("Deseas techo solar? (s/n): ");
								String radio = JOptionPane.showInputDialog("Deseas radio? (s/n): ");
								double kilometro = Double.parseDouble(km);
								int puertas = Integer.parseInt(puer);
								int plazas = Integer.parseInt(plaz);
								int numAirbags = Integer.parseInt(airbags);
								boolean techoSolar;
								boolean tieneRadio;
								if(solar.equals("s")){
									techoSolar = true;
								}
								else{
									techoSolar = false;
								}
								if(radio.equals("s")){
									tieneRadio = true;
								}
								else{
									tieneRadio = false;
								}
								Coche c = new Coche(marca, modelo, color, kilometro, puertas, plazas, numAirbags, techoSolar, tieneRadio);
								parque.add(c);
								JOptionPane.showMessageDialog(null, c.toString(c));
							}
							break;
					case 7:	if(Vehiculo.vehiculosCount == Vehiculo.MAX_VEHICULOS){
								JOptionPane.showMessageDialog(null, mensaje);
								}
							else{
								String marca = JOptionPane.showInputDialog("Introduce la marca: ");
								String modelo = JOptionPane.showInputDialog("Introduce la modelo: ");
								String color = JOptionPane.showInputDialog("Introduce el color: ");
								String km = JOptionPane.showInputDialog("Introduce los km: ");
								String puer = JOptionPane.showInputDialog("Introduce el numero de puertas: ");
								String plaz = JOptionPane.showInputDialog("Introduce el numero de plazas: ");
								String recorrido = JOptionPane.showInputDialog("Introduce el tipo de recorrido: ");
								String escolar = JOptionPane.showInputDialog("Es escolar? (s/n): ");
								double kilometro = Double.parseDouble(km);
								int puertas = Integer.parseInt(puer);
								int plazas = Integer.parseInt(plaz);
								boolean esEscolar;
								if(escolar.equals("s")){
									esEscolar = true;
								}
								else{
									esEscolar = false;
								}
								Autobus a = new Autobus(marca, modelo, color, kilometro, puertas, plazas, recorrido, esEscolar);
								parque.add(a);
								JOptionPane.showMessageDialog(null, a.toString(a));
							}
							break;
					case 8:	if(Vehiculo.vehiculosCount == Vehiculo.MAX_VEHICULOS){
								JOptionPane.showMessageDialog(null, mensaje);
								}
							else{
								String marca = JOptionPane.showInputDialog("Introduce la marca: ");
								String modelo = JOptionPane.showInputDialog("Introduce la modelo: ");
								String color = JOptionPane.showInputDialog("Introduce el color: ");
								String km = JOptionPane.showInputDialog("Introduce los km: ");
								String puer = JOptionPane.showInputDialog("Introduce el numero de puertas: ");
								String plaz = JOptionPane.showInputDialog("Introduce el numero de plazas: ");
								String potencia = JOptionPane.showInputDialog("Introduce la potencia del motor: ");
								String maletero = JOptionPane.showInputDialog("Deseas maletero? (s/n): ");
								double kilometro = Double.parseDouble(km);
								int puertas = Integer.parseInt(puer);
								int plazas = Integer.parseInt(plaz);
								boolean tieneMaletero;
								if(maletero.equals("s")){
									tieneMaletero = true;
								}
								else{
									tieneMaletero = false;
								}
								Motocicleta m = new Motocicleta(marca, modelo, color, kilometro, puertas, plazas, potencia, tieneMaletero);
								parque.add(m);
								JOptionPane.showMessageDialog(null, m.toString(m));
							}
							break;
					case 9:	if(Vehiculo.vehiculosCount == Vehiculo.MAX_VEHICULOS){
								JOptionPane.showMessageDialog(null, mensaje);
								}
							else{
								String marca = JOptionPane.showInputDialog("Introduce la marca: ");
								String modelo = JOptionPane.showInputDialog("Introduce la modelo: ");
								String color = JOptionPane.showInputDialog("Introduce el color: ");
								String km = JOptionPane.showInputDialog("Introduce los km: ");
								String puer = JOptionPane.showInputDialog("Introduce el numero de puertas: ");
								String plaz = JOptionPane.showInputDialog("Introduce el numero de plazas: ");
								String aeropuerto = JOptionPane.showInputDialog("Introduce el aeropuerto: ");
								String kg = JOptionPane.showInputDialog("Introduce los kg maximos: ");
								double kilometro = Double.parseDouble(km);
								int puertas = Integer.parseInt(puer);
								int plazas = Integer.parseInt(plaz);
								double maxKg = Double.parseDouble(kg);
								Avioneta av = new Avioneta(marca, modelo, color, kilometro, puertas, plazas, aeropuerto, maxKg);
								parque.add(av);
								JOptionPane.showMessageDialog(null, av.toString(av));
							}
							break;
					case 10:	if(Vehiculo.vehiculosCount == Vehiculo.MAX_VEHICULOS){
								JOptionPane.showMessageDialog(null, mensaje);
								}
							else{
								String marca = JOptionPane.showInputDialog("Introduce la marca: ");
								String modelo = JOptionPane.showInputDialog("Introduce la modelo: ");
								String color = JOptionPane.showInputDialog("Introduce el color: ");
								String km = JOptionPane.showInputDialog("Introduce los km: ");
								String puer = JOptionPane.showInputDialog("Introduce el numero de puertas: ");
								String plaz = JOptionPane.showInputDialog("Introduce el numero de plazas: ");
								String cocina = JOptionPane.showInputDialog("Tiene cocina? (s/n): ");
								String motores = JOptionPane.showInputDialog("Introduce los motores: ");
								String eslora = JOptionPane.showInputDialog("Introduce los metros de eslora: ");
								double kilometro = Double.parseDouble(km);
								int puertas = Integer.parseInt(puer);
								int plazas = Integer.parseInt(plaz);
								boolean tieneCocina;
								if(cocina.equals("s")){
									tieneCocina = true;
								}
								else{
									tieneCocina = false;
								}
								int numMotores = Integer.parseInt(motores);
								double metrosEslora = Double.parseDouble(eslora);	
								Yate y = new Yate(marca, modelo, color, kilometro, puertas, plazas, tieneCocina, numMotores, metrosEslora);
								parque.add(y);
								JOptionPane.showMessageDialog(null, y.toString(y));
							}
							break;
					case 11:	mostrarArray(parque);
							break;
					case 12: 	String mat = JOptionPane.showInputDialog("Introduce la matricula: ");
								mostrarArray(parque, mat);
								break;
					case 13: JOptionPane.showMessageDialog(null, "Gracias por usar nuestra fabrica. Hasta la proxima.");
							break;
					case 0: default: JOptionPane.showMessageDialog(null, "Introduce un numero entero entre 1 y 9.");
							break;
				}
			}
			catch (Exception localException) {
			JOptionPane.showMessageDialog(null, "Introduce un valor numerico");
			}
		}while(op != 13);
	}
	
	/**
	* Devuelve un número entero según el tipo de objeto recibido por parámetro.
	* @param o Es una referencia a un objeto Objeto.
	* @return Devuelve un número entero según el tipo de objeto recibido por parámetro.
	*/
	public static int tipoVehiculo(Object o){
		if(o instanceof Coche){
			return 1;
		}
		
		else if(o instanceof Autobus){
			return 2;
		}
		
		else if(o instanceof Motocicleta){
			return 3;
		}
		
		else if(o instanceof Avioneta){
			return 4;
		}
		
		else if(o instanceof Yate){
			return 5;
		}
		
		else{
			return -1;
		}
	}
	
	/**
	* Recorre el ArrayList recibido por parámetro y muestra las características de los objetos que contiene.
	* @param parque El ArrayList que contiene todos los vehículos.
	*/
	public static void mostrarArray(ArrayList parque){
		int index;
		for(int i = 0; i < parque.size(); i++){
			index = tipoVehiculo(parque.get(i));
			switch (index){
				case 1:	Coche c = (Coche) parque.get(i);
						JOptionPane.showMessageDialog(null, c.toString(c) + c.circular() + c.aparcar() + c.arrancar() + c.acelerar() + c.frenar());
				break;
				case 2: Autobus a = (Autobus) parque.get(i);
						JOptionPane.showMessageDialog(null, a.toString(a) + a.circular() + a.aparcar() + a.abrirPuertas() + a.arrancar() + a.acelerar() + a.frenar());
				break;
				case 3: Motocicleta m = (Motocicleta) parque.get(i);
						JOptionPane.showMessageDialog(null, m.toString(m) + m.circular() + m.aparcar() + m.brincar() + m.arrancar() + m.acelerar() + m.frenar());
				break;
				case 4:	Avioneta av = (Avioneta) parque.get(i);
						JOptionPane.showMessageDialog(null, av.toString(av) + av.volar() + av.despegar() + av.aterrizar() + av.arrancar() + av.acelerar() + av.frenar());
				break;
				case 5:	Yate y = (Yate) parque.get(i);
						JOptionPane.showMessageDialog(null, y.toString(y) + y.navegar() + y.zarpar() + y.atracar() + y.arrancar() + y.acelerar() + y.frenar());
				break;
				case -1:
				break;
			}
		}
	}
	
	/**
	* Sobrecarga del método mostrarArray(ArrayList parque).
	* Recorre el ArrayList recibido por parámetro y muestra las características del objeto que contiene la matrícula recibida por parámetro.
	* @param parque El ArrayList que contiene todos los vehículos.
	* @param mat La matrícula del Vehiculo buscado.
	*/
	public static void mostrarArray(ArrayList parque, String mat){
		int index;
		for(int i = 0; i < parque.size(); i++){
			index = tipoVehiculo(parque.get(i));
			switch (index){
				case 1:	Coche c = (Coche) parque.get(i);
						if(c.getMatricula().equals(mat)){
							JOptionPane.showMessageDialog(null, c.toString(c) + c.circular() + c.aparcar() + c.arrancar() + c.acelerar() + c.frenar());
						}
						else{
							JOptionPane.showMessageDialog(null, "La matricula introducida no existe.");
						}
				break;
				case 2: Autobus a = (Autobus) parque.get(i);
						if(a.getMatricula().equals(mat)){
							JOptionPane.showMessageDialog(null, a.toString(a) + a.circular() + a.aparcar() + a.abrirPuertas() + a.arrancar() + a.acelerar() + a.frenar());
						}
						else{
							JOptionPane.showMessageDialog(null, "La matricula introducida no existe.");
						}
				break;
				case 3: Motocicleta m = (Motocicleta) parque.get(i);
						if(m.getMatricula().equals(mat)){
							JOptionPane.showMessageDialog(null, m.toString(m) + m.circular() + m.aparcar() + m.brincar() + m.arrancar() + m.acelerar() + m.frenar());
						}
						else{
							JOptionPane.showMessageDialog(null, "La matricula introducida no existe.");
						}
				break;
				case 4:	Avioneta av = (Avioneta) parque.get(i);
						if(av.getMatricula().equals(mat)){
							JOptionPane.showMessageDialog(null, av.toString(av) + av.volar() + av.despegar() + av.aterrizar() + av.arrancar() + av.acelerar() + av.frenar());
						}
						else{
							JOptionPane.showMessageDialog(null, "La matricula introducida no existe.");
						}
				break;
				case 5:	Yate y = (Yate) parque.get(i);
						if(y.getMatricula().equals(mat)){
							JOptionPane.showMessageDialog(null, y.toString(y) + y.navegar() + y.zarpar() + y.atracar() + y.arrancar() + y.acelerar() + y.frenar());
						}
						else{
							JOptionPane.showMessageDialog(null, "La matricula introducida no existe.");
						}
				break;
				case -1:
				break;
			}
		}
	}
}