/**
* Clase Coche.
* numAirbags El valor del número de airbags del coche.
* techoSolar El valor del techo solar del coche.
* tieneRadio El valor de la radio del coche.
@author Javi Sirvent
*/
public class Coche extends Vehiculo implements PuedeCircular{
	
	private int numAirbags;
	private boolean techoSolar;
	private boolean tieneRadio;
	
	/**
	* Crea un Coche nuevo llamando al constructor de la clase Vehiculo.
	*/
	public Coche(){
		super();
		setNumAirbags(3);
		setTechoSolar(false);
		setTieneRadio(false);
	}
	
	/**
	* Crea un Coche nuevo con los párametros recibidos llamando al constructor de la clase Vehiculo.
	*/
	public Coche(String marca, String modelo, String color, double kilometros, int numPuertas, int numPlazas, int numAirbags, boolean techoSolar, boolean tieneRadio){
		super(marca, modelo, color, kilometros, numPuertas, numPlazas);
		setNumAirbags(numAirbags);
		setTechoSolar(techoSolar);
		setTieneRadio(tieneRadio);
	}
	
	/**
	* Devuelve una cadena de texto con las caracteristicas del Coche recibido por parámetro.
	* @param c Coche recibido por parámetro
	* @return La cadena de texto creada.
	*/
	public String toString(Coche c){
		String solar;
		String radio;
		if(c.techoSolar){
			solar = "tiene techo solar ";
		}
		else{
			solar = "no tiene techo solar ";
		}
		if(c.tieneRadio){
			radio = "y tiene radio. \n";
		}
		else{
			radio = "y no tiene radio. \n";
		}
		String s = "El coche tiene " + c.numAirbags + " airbags, " + solar + radio + super.toString(c);
		return s;
	}
		
	/**
	* Devuelve una cadena de texto con la acción que realiza el coche.
	* @return s La acción que realiza el Coche.
	*/
	public String circular(){
		 String s = "Este vehiculo es un coche. Puede circular por la carretera.\n";
		 return s;
	}
	
	/**
	* Pone los kilómetros a 0, le añade un techo solar si no lo tenía ya y lo pinta del color pasado por parámetro.
	* @param color1 El valor de la variable color.
	*/
	public String tunear(String color1){
		
		color = color1;
		kilometros = 0;
		String s;
		
		if(!techoSolar){
			techoSolar = true;
			s = "Se han puesto los km a 0, se ha instalado un techo solar y se ha pintado de " + color1 + "\n";
		}
		else{
			s = "Se han puesto los km a 0 y se ha pintado de " + color1 + "\n";
		}
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza el coche.
	* @return s La acción que realiza el Coche.
	*/
	public String aparcar(){
		String s = "El coche esta aparcando.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza el coche.
	* @return s La acción que realiza el Coche.
	*/
	public String arrancar(){
		String s = "El coche esta arrancando.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza el coche.
	* @return s La acción que realiza el Coche.
	*/
	public String acelerar(){
		String s =  "El coche esta acelerando.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza el coche.
	* @return s La acción que realiza el Coche.
	*/
	public String frenar(){
		String s = "El coche esta frenando.\n";
		return s;
	}
	
	/**
	* Asigna el número de airbags al Coche.
	* @param n El valor de la variable numAirbags.
	*/
	public void setNumAirbags(int n){
		numAirbags = n;
	}
	
	/**
	*Devuelve el valor de la variable numAirbags
	*@return El valor de la variable numAirbags
	*/
	public int getNumAirbags(){
		return numAirbags;
	}
	
	/**
	* Asigna el valor del techo solar al Coche.
	* @param t El valor de la variable techoSolar.
	*/
	public void setTechoSolar(boolean t){
		techoSolar = t;
	}
	
	/**
	*Devuelve el valor de la variable techoSolar
	*@return El valor de la variable techoSolar
	*/
	public boolean getTechoSolar(){
		return techoSolar;
	}
	
	/**
	* Asigna el valor de la radio al Coche.
	* @param t El valor de la variable tieneRadio.
	*/
	public void setTieneRadio(boolean t){
		tieneRadio = t;
	}
	
	/**
	*Devuelve el valor de la variable tieneRadio
	*@return El valor de la variable tieneRadio
	*/
	public boolean getTieneRadio(){
		return tieneRadio;
	}
}