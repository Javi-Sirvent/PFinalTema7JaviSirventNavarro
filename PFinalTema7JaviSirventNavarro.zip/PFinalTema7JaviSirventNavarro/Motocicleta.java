/**
* Clase Motocicleta.
* potenciaMotor El valor de la potencia del motor de la Motocicleta.
* tieneMaletero El valor del maletero de la Motocicleta.
@author Javi Sirvent
*/
public class Motocicleta extends Vehiculo implements PuedeCircular{
	
	private String potenciaMotor;
	private boolean tieneMaletero;
	
	/**
	* Crea una Motocicleta nueva llamando al constructor de la clase Vehiculo.
	*/
	public Motocicleta(){
		super();
		setPotenciaMotor("50 CV");
		setTieneMaletero(false);
	}
	
	/**
	* Crea una Motocicleta nueva con los párametros recibidos llamando al constructor de la clase Vehiculo.
	*/
	public Motocicleta(String marca, String modelo, String color, double kilometros, int numPuertas, int numPlazas, String potenciaMotor, boolean tieneMaletero){
		super(marca, modelo, color, kilometros, numPuertas, numPlazas);
		setPotenciaMotor(potenciaMotor);
		setTieneMaletero(tieneMaletero);
	}
	
	/**
	* Devuelve una cadena de texto con las caracteristicas de la Motocicleta recibida por parámetro.
	* @param m Motocicleta recibida por parámetro
	* @return La cadena de texto creada.
	*/
	public String toString(Motocicleta m){
		String maletero;
		if(m.tieneMaletero){
			maletero = " y tiene maletero. \n";
		}
		else{
			maletero = " y no tiene maletero. \n";
		}
		String s = "La motocicleta tiene una potencia de " + m.potenciaMotor + maletero + super.toString(m);
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza la Motocicleta.
	* @return s La acción que realiza la Motocicleta.
	*/
	public String circular(){
		String s = "Este vehiculo es una motocicleta. Puede circular por la carretera.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza la Motocicleta.
	* @return s La acción que realiza la Motocicleta.
	*/
	public String aparcar(){
		String s = "La motocicleta esta aparcando.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza la Motocicleta.
	* @return s La acción que realiza la Motocicleta.
	*/
	public String brincar(){
		String s = "La motocicleta esta brincando.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza la Motocicleta.
	* @return s La acción que realiza la Motocicleta.
	*/
	public String arrancar(){
		String s = "La motocicleta esta arrancando.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza la Motocicleta.
	* @return s La acción que realiza la Motocicleta.
	*/
	public String acelerar(){
		String s = "La motocicleta esta acelerando.\n";
		return s;
	}
	
	/**
	* Devuelve una cadena de texto con la acción que realiza la Motocicleta.
	* @return s La acción que realiza la Motocicleta.
	*/
	public String frenar(){
		String s = "La motocicleta esta frenando.\n";
		return s;
	}
	
	/**
	* Asigna el valor de la potencia del motor de la Motocicleta.
	* @param p El valor de la variable potenciaMotor.
	*/
	public void setPotenciaMotor(String p){
		potenciaMotor = p;
	}
	
	/**
	* Devuelve el valor de la variable potenciaMotor
	* @return El valor de la variable potenciaMotor
	*/
	public String getPotenciaMotor(){
		return potenciaMotor;
	}
	
	/**
	* Asigna el valor del tipo de maletero de la Motocicleta.
	* @param t El valor de la variable tieneMaletero.
	*/
	public void setTieneMaletero(boolean t){
		tieneMaletero = t;
	}
	
	/**
	* Devuelve el valor de la variable tieneMaletero
	* @return El valor de la variable tieneMaletero
	*/
	public boolean getTieneMaletero(){
		return tieneMaletero;
	}
}